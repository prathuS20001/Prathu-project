# ICRMS Working Project

## Run
1. Install Node.js LTS.
2. Open Command Prompt in this project folder.
3. Run:
   npm install
   npm run dev
4. Open the localhost URL shown by Vite.

## Demo login
Any non-empty email/employee ID and password will work.

## Included
Login, Dashboard, Create Case wizard, Cases, Approval Center, University Response, Reports, Case Details, responsive UI, dark mode, local in-memory workflow.
