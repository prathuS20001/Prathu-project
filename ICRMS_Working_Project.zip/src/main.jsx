import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  LayoutDashboard, FilePlus2, Files, ClipboardCheck, Building2, BarChart3,
  Bell, Search, UserCircle, LogOut, Menu, X, Moon, Sun, ChevronRight,
  CheckCircle2, Clock3, XCircle, Send, Paperclip, Eye, Download,
  MoreHorizontal, ArrowLeft, Plus, Filter, ShieldCheck, Activity,
  AlertCircle, FileText, TrendingUp
} from "lucide-react";
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, PieChart, Pie, Cell, BarChart, Bar
} from "recharts";
import "./styles.css";

const initialCases = [
  { id:"ICR-2026-001", applicant:"Aarav Sharma", university:"Delhi Technical University", type:"Admission Verification", date:"11 Aug 2026", status:"Pending", priority:"High", officer:"Priya Singh" },
  { id:"ICR-2026-002", applicant:"Riya Verma", university:"Graphic Era University", type:"Document Verification", date:"10 Aug 2026", status:"Approved", priority:"Medium", officer:"Rahul Mehta" },
  { id:"ICR-2026-003", applicant:"Kabir Negi", university:"UPES", type:"Transfer Case", date:"09 Aug 2026", status:"University Response", priority:"High", officer:"Ankit Rawat" },
  { id:"ICR-2026-004", applicant:"Mehak Gupta", university:"Amity University", type:"Eligibility Review", date:"08 Aug 2026", status:"Rejected", priority:"Low", officer:"Priya Singh" },
  { id:"ICR-2026-005", applicant:"Vansh Raj", university:"Sharda University", type:"Admission Verification", date:"07 Aug 2026", status:"Approved", priority:"Medium", officer:"Rahul Mehta" }
];

const trend = [
  {month:"Mar", cases:28},{month:"Apr", cases:42},{month:"May", cases:37},
  {month:"Jun", cases:58},{month:"Jul", cases:71},{month:"Aug", cases:84}
];

const universities = [
  {name:"Delhi Technical University", value:34},
  {name:"Graphic Era University", value:24},
  {name:"UPES", value:19},
  {name:"Amity University", value:15},
  {name:"Others", value:8}
];

function App(){
  const [loggedIn, setLoggedIn] = useState(false);
  const [page, setPage] = useState("dashboard");
  const [dark, setDark] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [cases, setCases] = useState(initialCases);
  const [selected, setSelected] = useState(null);
  const [query, setQuery] = useState("");
  const [toast, setToast] = useState("");

  const navigate = p => { setPage(p); setMobileOpen(false); window.scrollTo({top:0, behavior:"smooth"}); };
  const notify = msg => { setToast(msg); setTimeout(()=>setToast(""), 2500); };

  if(!loggedIn) return <Login onLogin={()=>setLoggedIn(true)} dark={dark}/>;

  const activeCase = cases.find(c=>c.id===selected);

  const approve = id => {
    setCases(cs=>cs.map(c=>c.id===id ? {...c,status:"Approved"} : c));
    notify("Case approved successfully");
  };
  const reject = id => {
    setCases(cs=>cs.map(c=>c.id===id ? {...c,status:"Rejected"} : c));
    notify("Case rejected");
  };

  return (
    <div className={dark ? "app dark" : "app"}>
      <Sidebar page={page} navigate={navigate} mobileOpen={mobileOpen} close={()=>setMobileOpen(false)} onLogout={()=>setLoggedIn(false)}/>
      <main className="main">
        <header className="topbar">
          <button className="icon-btn mobile-menu" onClick={()=>setMobileOpen(true)}><Menu size={21}/></button>
          <div className="crumb"><span>ICRMS</span><ChevronRight size={15}/><b>{pageTitle(page)}</b></div>
          <div className="top-actions">
            <div className="searchbox"><Search size={17}/><input placeholder="Search cases..." value={query} onChange={e=>setQuery(e.target.value)}/></div>
            <button className="icon-btn" title="Notifications"><Bell size={19}/><i className="dot"/></button>
            <button className="icon-btn" onClick={()=>setDark(!dark)} title="Theme">{dark?<Sun size={19}/>:<Moon size={19}/>}</button>
            <div className="avatar">PB</div>
          </div>
        </header>

        <div className="content">
          {page==="dashboard" && <Dashboard cases={cases} navigate={navigate} setSelected={setSelected}/>}
          {page==="create" && <CreateCase onCreate={c=>{setCases(cs=>[c,...cs]); notify("Case created successfully"); navigate("cases")}}/>}
          {page==="cases" && <Cases cases={cases} query={query} setSelected={setSelected} navigate={navigate}/>}
          {page==="approval" && <Approval cases={cases} approve={approve} reject={reject} setSelected={setSelected} />}
          {page==="university" && <University cases={cases} setSelected={setSelected} notify={notify}/>}
          {page==="reports" && <Reports cases={cases}/>}
          {page==="case" && activeCase && <CaseDetails item={activeCase} back={()=>navigate("cases")} approve={approve} reject={reject} notify={notify}/>}
        </div>
        {toast && <div className="toast"><CheckCircle2 size={18}/>{toast}</div>}
      </main>
    </div>
  );
}

function Login({onLogin,dark}){
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [error,setError]=useState("");
  const submit=e=>{e.preventDefault(); if(email && password) onLogin(); else setError("Enter email and password to continue.");};
  return <div className={dark?"login-page dark":"login-page"}>
    <div className="login-art">
      <div className="brand large"><div className="brand-mark"><ShieldCheck size={26}/></div><span>ICRMS</span></div>
      <div className="hero-copy">
        <span className="eyebrow">ENTERPRISE CASE MANAGEMENT</span>
        <h1>Manage every case.<br/><em>Move work forward.</em></h1>
        <p>A modern workflow platform for case intake, approvals, university responses and reporting.</p>
      </div>
      <div className="login-stats"><div><b>98.4%</b><span>Resolution rate</span></div><div><b>2.4k+</b><span>Cases managed</span></div><div><b>24/7</b><span>Workflow visibility</span></div></div>
    </div>
    <div className="login-panel">
      <form className="login-card" onSubmit={submit}>
        <div className="mobile-brand"><div className="brand-mark"><ShieldCheck size={22}/></div><b>ICRMS</b></div>
        <span className="eyebrow">WELCOME BACK</span><h2>Sign in to your workspace</h2>
        <p className="muted">Use any email and password for this demo.</p>
        <label>Email / Employee ID<input value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@company.com"/></label>
        <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="••••••••"/></label>
        <div className="login-row"><label className="check"><input type="checkbox"/> Remember me</label><a href="#forgot" onClick={e=>e.preventDefault()}>Forgot password?</a></div>
        {error && <div className="error"><AlertCircle size={16}/>{error}</div>}
        <button className="primary wide">Sign in <ChevronRight size={18}/></button>
        <div className="secure"><ShieldCheck size={15}/> Secure enterprise workspace</div>
      </form>
    </div>
  </div>
}

function Sidebar({page,navigate,mobileOpen,close,onLogout}){
  const items=[
    ["dashboard","Dashboard",LayoutDashboard],["cases","All Cases",Files],
    ["create","Create Case",FilePlus2],["approval","Approval Center",ClipboardCheck],
    ["university","University Response",Building2],["reports","Reports & Analytics",BarChart3]
  ];
  return <aside className={mobileOpen?"sidebar open":"sidebar"}>
    <div className="side-head"><div className="brand"><div className="brand-mark"><ShieldCheck size={21}/></div><span>ICRMS</span></div><button className="icon-btn close" onClick={close}><X/></button></div>
    <div className="workspace"><div className="workspace-icon">W</div><div><b>Operations</b><span>Enterprise Workspace</span></div><ChevronRight size={15}/></div>
    <nav>{items.map(([id,label,Icon])=><button key={id} className={page===id?"nav active":"nav"} onClick={()=>navigate(id)}><Icon size={19}/><span>{label}</span>{id==="approval"&&<b className="nav-count">4</b>}</button>)}</nav>
    <div className="side-bottom">
      <div className="mini-card"><Activity size={18}/><div><b>System healthy</b><span>All services operational</span></div></div>
      <button className="nav" onClick={onLogout}><LogOut size={19}/><span>Sign out</span></button>
    </div>
  </aside>
}

function pageTitle(p){return {dashboard:"Dashboard",create:"Create Case",cases:"All Cases",approval:"Approval Center",university:"University Response",reports:"Reports & Analytics",case:"Case Details"}[p]}

function Dashboard({cases,navigate,setSelected}){
  const counts = {total:cases.length,pending:cases.filter(x=>x.status==="Pending").length,approved:cases.filter(x=>x.status==="Approved").length,response:cases.filter(x=>x.status==="University Response").length};
  return <><div className="page-head"><div><span className="eyebrow">TUESDAY, 11 AUG 2026</span><h1>Good evening, Prathu <span>👋</span></h1><p className="muted">Here’s what’s happening across your case workflow today.</p></div><button className="primary" onClick={()=>navigate("create")}><Plus size={18}/> Create new case</button></div>
    <div className="stats-grid">
      <Stat title="Total Cases" value={counts.total+84} change="+12.8%" icon={Files} cls="blue"/>
      <Stat title="Pending Review" value={counts.pending+17} change="+4.2%" icon={Clock3} cls="amber"/>
      <Stat title="Approved Cases" value={counts.approved+62} change="+18.6%" icon={CheckCircle2} cls="green"/>
      <Stat title="University Response" value={counts.response+9} change="+6.4%" icon={Building2} cls="purple"/>
    </div>
    <div className="grid-2">
      <Card title="Case volume" subtitle="Monthly case activity"><div className="chart"><ResponsiveContainer width="100%" height="100%"><AreaChart data={trend}><defs><linearGradient id="fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#2F80ED" stopOpacity=".28"/><stop offset="100%" stopColor="#2F80ED" stopOpacity="0"/></linearGradient></defs><CartesianGrid vertical={false} stroke="#E9EDF4"/><XAxis dataKey="month" axisLine={false} tickLine={false}/><YAxis axisLine={false} tickLine={false}/><Tooltip/><Area type="monotone" dataKey="cases" stroke="#2F80ED" fill="url(#fill)" strokeWidth={3}/></AreaChart></ResponsiveContainer></div></Card>
      <Card title="Cases by university" subtitle="Distribution this month"><div className="pie-wrap"><ResponsiveContainer width="54%" height={190}><PieChart><Pie data={universities} dataKey="value" innerRadius={58} outerRadius={82} paddingAngle={4}>{universities.map((_,i)=><Cell key={i} fill={["#123A78","#2F80ED","#6C63FF","#22A06B","#AAB4C3"][i]}/>)}</Pie><Tooltip/></PieChart></ResponsiveContainer><div className="legend">{universities.map((u,i)=><div key={u.name}><span className="legend-dot" style={{background:["#123A78","#2F80ED","#6C63FF","#22A06B","#AAB4C3"][i]}}/><span>{u.name}</span><b>{u.value}%</b></div>)}</div></div></Card>
    </div>
    <Card title="Recent cases" subtitle="Latest workflow activity" action={<button className="text-btn" onClick={()=>navigate("cases")}>View all <ChevronRight size={15}/></button>}>
      <CaseTable cases={cases.slice(0,5)} setSelected={setSelected} navigate={navigate}/>
    </Card>
  </>
}

function Stat({title,value,change,icon:Icon,cls}){return <div className="stat"><div className={"stat-icon "+cls}><Icon size={21}/></div><div className="stat-body"><span>{title}</span><b>{value}</b><small className="positive"><TrendingUp size={13}/> {change} <i>vs last month</i></small></div></div>}
function Card({title,subtitle,action,children}){return <section className="card"><div className="card-head"><div><h3>{title}</h3><span>{subtitle}</span></div>{action}</div>{children}</section>}

function Cases({cases,query,setSelected,navigate}){
  const [status,setStatus]=useState("All");
  const filtered=cases.filter(c=>(status==="All"||c.status===status) && Object.values(c).join(" ").toLowerCase().includes(query.toLowerCase()));
  return <><div className="page-head"><div><span className="eyebrow">CASE MANAGEMENT</span><h1>All Cases</h1><p className="muted">Search, review and track every case in one place.</p></div><button className="primary" onClick={()=>navigate("create")}><Plus size={18}/> New case</button></div>
  <Card title={`${filtered.length} cases`} subtitle="Updated in real time"><div className="filters"><div className="filter-tabs">{["All","Pending","Approved","University Response","Rejected"].map(s=><button className={status===s?"selected":""} onClick={()=>setStatus(s)} key={s}>{s}</button>)}</div><button className="secondary"><Filter size={16}/> Filters</button></div><CaseTable cases={filtered} setSelected={setSelected} navigate={navigate}/></Card></>
}

function CaseTable({cases,setSelected,navigate}){
 return <div className="table-wrap"><table><thead><tr><th>Case ID</th><th>Applicant</th><th>University</th><th>Type</th><th>Date</th><th>Status</th><th></th></tr></thead><tbody>{cases.map(c=><tr key={c.id}><td><button className="case-link" onClick={()=>{setSelected(c.id);navigate("case")}}>{c.id}</button></td><td><b>{c.applicant}</b><small>{c.officer}</small></td><td>{c.university}</td><td>{c.type}</td><td>{c.date}</td><td><Status s={c.status}/></td><td><button className="icon-btn"><MoreHorizontal size={18}/></button></td></tr>)}</tbody></table>{!cases.length&&<div className="empty"><Files size={32}/><b>No cases found</b><span>Try changing your filters or search.</span></div>}</div>
}

function Status({s}){return <span className={"status "+s.toLowerCase().replaceAll(" ","-")}><i/>{s}</span>}

function CreateCase({onCreate}){
 const [step,setStep]=useState(1);
 const [form,setForm]=useState({applicant:"",university:"",type:"Admission Verification",email:"",details:""});
 const update=(k,v)=>setForm({...form,[k]:v});
 const submit=()=>onCreate({id:`ICR-2026-${String(Math.floor(Math.random()*900)+100)}`,applicant:form.applicant||"New Applicant",university:form.university||"University",type:form.type,date:"11 Aug 2026",status:"Pending",priority:"Medium",officer:"Prathu Bhati"});
 return <><div className="page-head"><div><span className="eyebrow">CASE INTAKE</span><h1>Create New Case</h1><p className="muted">Capture the case details and submit it into the approval workflow.</p></div></div>
 <div className="steps">{["Basic details","Case information","Documents","Review"].map((x,i)=><div className={step===i+1?"step active":step>i+1?"step done":"step"} key={x}><span>{step>i+1?<CheckCircle2 size={17}/>:i+1}</span><b>{x}</b>{i<3&&<div className="step-line"/>}</div>)}</div>
 <Card title={["Basic details","Case information","Documents","Review"][step-1]} subtitle={`Step ${step} of 4`}>
 {step===1&&<div className="form-grid"><Field label="Applicant name" value={form.applicant} onChange={v=>update("applicant",v)} placeholder="Enter full name"/><Field label="Email" value={form.email} onChange={v=>update("email",v)} placeholder="applicant@email.com"/><Field label="University" value={form.university} onChange={v=>update("university",v)} placeholder="University name"/><Field label="Case type" select value={form.type} onChange={v=>update("type",v)} options={["Admission Verification","Document Verification","Transfer Case","Eligibility Review"]}/></div>}
 {step===2&&<div><label>Case description<textarea value={form.details} onChange={e=>update("details",e.target.value)} placeholder="Describe the case and required action..."/></label><div className="info-box"><AlertCircle size={18}/><span>Provide clear details. This information will be visible to the reviewing officer.</span></div></div>}
 {step===3&&<div className="upload"><div className="upload-icon"><Paperclip/></div><h3>Drop documents here</h3><p>Upload PDF, JPG or PNG files up to 10 MB.</p><button className="secondary" onClick={()=>document.getElementById("file").click()}>Choose files</button><input id="file" hidden type="file" multiple/><div className="fake-file"><FileText size={18}/><span>Supporting documents</span><b>Ready to upload</b></div></div>}
 {step===4&&<div className="review"><div><span>Applicant</span><b>{form.applicant||"—"}</b></div><div><span>University</span><b>{form.university||"—"}</b></div><div><span>Case type</span><b>{form.type}</b></div><div className="review-full"><span>Description</span><b>{form.details||"No description provided."}</b></div></div>}
 <div className="form-actions">{step>1?<button className="secondary" onClick={()=>setStep(step-1)}><ArrowLeft size={17}/> Back</button>:<span/>}{step<4?<button className="primary" onClick={()=>setStep(step+1)}>Continue <ChevronRight size={17}/></button>:<button className="primary" onClick={submit}><Send size={17}/> Submit case</button>}</div>
 </Card></>
}

function Field({label,value,onChange,placeholder,select,options=[]}){return <label>{label}{select?<select value={value} onChange={e=>onChange(e.target.value)}>{options.map(o=><option key={o}>{o}</option>)}</select>:<input value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}/>}</label>}

function Approval({cases,approve,reject,setSelected}){
 const pending=cases.filter(c=>c.status==="Pending");
 return <><div className="page-head"><div><span className="eyebrow">WORKFLOW</span><h1>Approval Center</h1><p className="muted">Review cases waiting for your decision.</p></div><div className="approval-badge"><Clock3 size={16}/>{pending.length} awaiting review</div></div>
 <div className="approval-grid">{pending.map(c=><div className="approval-card" key={c.id}><div className="approval-top"><Status s={c.status}/><button className="icon-btn"><MoreHorizontal size={18}/></button></div><span className="eyebrow">{c.id}</span><h3>{c.applicant}</h3><p>{c.type} · {c.university}</p><div className="approval-meta"><span>Assigned to <b>{c.officer}</b></span><span>Priority <b>{c.priority}</b></span></div><div className="approval-actions"><button className="secondary" onClick={()=>setSelected(c.id)}><Eye size={16}/> Review</button><button className="danger" onClick={()=>reject(c.id)}><XCircle size={16}/> Reject</button><button className="primary" onClick={()=>approve(c.id)}><CheckCircle2 size={16}/> Approve</button></div></div>)}{!pending.length&&<div className="empty card"><CheckCircle2 size={35}/><b>All caught up</b><span>No cases are waiting for approval.</span></div>}</div>
 </> 
}

function University({cases,setSelected,notify}){
 const response=cases.filter(c=>c.status==="University Response");
 return <><div className="page-head"><div><span className="eyebrow">EXTERNAL WORKFLOW</span><h1>University Response</h1><p className="muted">Track cases sent to universities and manage incoming responses.</p></div></div>
 <div className="response-tabs"><button className="selected">Awaiting response <b>{response.length}</b></button><button>Responded <b>18</b></button><button>All sent <b>42</b></button></div>
 <Card title="Awaiting university response" subtitle="Cases currently with partner institutions"><div className="response-list">{response.map(c=><div className="response-row" key={c.id}><div className="uni-logo"><Building2 size={20}/></div><div className="response-main"><b>{c.university}</b><span>{c.id} · {c.applicant}</span></div><Status s={c.status}/><span className="days">2 days waiting</span><button className="secondary" onClick={()=>{setSelected(c.id);notify("Case selected")}}>Open</button></div>)}</div></Card></>
}

function Reports({cases}){
 const data=[{name:"Pending",value:cases.filter(c=>c.status==="Pending").length+17},{name:"Approved",value:cases.filter(c=>c.status==="Approved").length+62},{name:"Rejected",value:cases.filter(c=>c.status==="Rejected").length+14},{name:"Response",value:cases.filter(c=>c.status==="University Response").length+9}];
 return <><div className="page-head"><div><span className="eyebrow">INSIGHTS</span><h1>Reports & Analytics</h1><p className="muted">Understand case performance and workflow health.</p></div><button className="secondary" onClick={()=>alert("Demo export generated.")}><Download size={17}/> Export report</button></div>
 <div className="grid-2"><Card title="Status distribution" subtitle="Current portfolio"><div className="chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={data}><CartesianGrid vertical={false} stroke="#E9EDF4"/><XAxis dataKey="name" axisLine={false} tickLine={false}/><YAxis axisLine={false} tickLine={false}/><Tooltip/><Bar dataKey="value" fill="#2F80ED" radius={[7,7,0,0]}/></BarChart></ResponsiveContainer></div></Card><Card title="Performance snapshot" subtitle="This month"><div className="report-metrics"><div><b>94.2%</b><span>SLA compliance</span></div><div><b>2.8 days</b><span>Avg. turnaround</span></div><div><b>86.5%</b><span>First-pass approval</span></div><div><b>1,284</b><span>Documents processed</span></div></div></Card></div>
 <Card title="Monthly trend" subtitle="Cases created vs completed"><div className="chart tall"><ResponsiveContainer width="100%" height="100%"><AreaChart data={trend}><CartesianGrid vertical={false} stroke="#E9EDF4"/><XAxis dataKey="month" axisLine={false} tickLine={false}/><YAxis axisLine={false} tickLine={false}/><Tooltip/><Area type="monotone" dataKey="cases" stroke="#123A78" fill="#123A78" fillOpacity=".10" strokeWidth={3}/></AreaChart></ResponsiveContainer></div></Card>
 </> 
}

function CaseDetails({item,back,approve,reject,notify}){
 return <><button className="back-btn" onClick={back}><ArrowLeft size={17}/> Back to cases</button><div className="case-hero"><div><span className="eyebrow">{item.id}</span><h1>{item.applicant}</h1><p>{item.type} · {item.university}</p></div><Status s={item.status}/></div>
 <div className="detail-grid"><Card title="Case overview" subtitle="Applicant and workflow information"><div className="detail-fields"><div><span>Applicant</span><b>{item.applicant}</b></div><div><span>University</span><b>{item.university}</b></div><div><span>Case type</span><b>{item.type}</b></div><div><span>Assigned officer</span><b>{item.officer}</b></div><div><span>Submitted</span><b>{item.date}</b></div><div><span>Priority</span><b>{item.priority}</b></div></div></Card>
 <Card title="Activity timeline" subtitle="Complete case history"><div className="timeline"><Timeline title="Case created" text="Application submitted into ICRMS" time="Today · 10:24 AM" done/><Timeline title="Documents verified" text="Initial document review completed" time="Today · 11:05 AM" done/><Timeline title="Approval pending" text="Awaiting officer decision" time="Today · 11:22 AM" active/><Timeline title="University response" text="Will start after approval" time="Pending"/></div></Card></div>
 {item.status==="Pending"&&<div className="decision-bar"><div><b>Ready for decision?</b><span>Review all submitted information before taking action.</span></div><div><button className="danger" onClick={()=>reject(item.id)}>Reject</button><button className="primary" onClick={()=>approve(item.id)}>Approve case</button></div></div>}
 </> 
}
function Timeline({title,text,time,done,active}){return <div className="timeline-item"><div className={done?"tl-dot done":active?"tl-dot active":"tl-dot"}>{done?<CheckCircle2 size={14}/>:active?<Clock3 size={14}/>:<span/>}</div><div><b>{title}</b><span>{text}</span><small>{time}</small></div></div>}

createRoot(document.getElementById("root")).render(<App/>);
